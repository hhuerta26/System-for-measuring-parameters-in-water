global pH_global
global EC_global
global Tds_global
global Sal_global
global Temperatura_global
global fecha_Com_global
fecha=fecha_Com_global;
%disp(fecha)

if(length(fecha)==14)%se separa la fecha y hora
    
    if(fecha(9)==',')
        hora=fecha(10:1:14);
        fecha(9:1:14)='';
        fecha=strcat(fecha,',');
        fecha={fecha};
        hora=strcat(hora,',');
        hora={hora};
    end
end

%matriz=zeros(1,3)
filename = 'testdata.xlsx';%nombre del archivo
xlRange = 'A1';%se especifica la celda a leer 
sheet = 'Hoja1';%se especifica la hoja en la que se va leer
contador = xlsread(filename,'Hoja1',xlRange);%se lee la celda y se le asigna el valor a contador
if(contador>=0)%si contador>0 es porque ya hay datos en la hoja de excel
    matriz=[str2num(pH_global),str2num(EC_global),str2num(Tds_global),str2num(Sal_global),str2num(Temperatura_global),fecha,hora];%se genera una matriz con los datos
    cad1=int2str(contador);%se crea una cadena donde se va escribir
    cad2=strcat('B',cad1);
    cad3=strcat(':H',cad1);
    cad5=strcat(cad2,cad3);%aqui termina la construcion de la cadena ejemplo B1:H1 se va escribir en coluna B fila 1 hasta columna H 
    xlswrite(filename,matriz,sheet,cad5)%se crea el archivo si no existe, pero no se escribe nada
    contador = contador+1;%contador aumenta para escribir en el archivo y decir que se escribio un dato ma
    xlRange = 'A1';
    xlswrite(filename,contador,sheet,xlRange)%se escribe contador (contador cuenta el numero de datos, este se utiliza para saber en cual columna se va escribir)
    set(handles.pH,'String',pH_global);%se muestran los datos recibidos.
    set(handles.Ec,'String',EC_global);
    set(handles.Sst,'String',Tds_global);
    set(handles.Sal,'String',Sal_global);
    set(handles.Temperatura,'String',Temperatura_global);
    set(handles.Fecha,'String',fecha);
    set(handles.Hora,'String',hora);
end

