
    filename = 'testdata.xlsx';%nombre del archivo
    data = {''} ;%data sin ningun valor
    sheet = 'Hoja1';%se especifica la hoja en la cual se va a trabajar
    xlRange = 'A2';%se especifica la celda donde se va escribir
    xlswrite(filename,data,sheet,xlRange)%se crea el archivo si no existe, pero no se escribe nada
    %se lee contador
    try%try-catch para cahcar el error, s� se produce un error al leer el xls
        xlRange = 'A1';%se especifica la celda a leer 
        sheet = 'Hoja1';%se especifica la hoja en la que se va leer
        cont_str = xlsread(filename,'Hoja1',xlRange);%se lee la celda y se le asigna el valor a contador
        contador=int2str(cont_str);
        open_error=0;%variable para saber si existio algun error al leer el archivo = 0 s� no hay error
    catch
        open_error=1;%variable para saber si existio algun error al leer el archivo =1 si hay error
    end
    if(contador>=0)%s� contador no es mayor o igual a 0, contador=[] (contador vacio);esto porque no existe ningun dato, entonces el archivo xls se acaba de crear. Por elo se debe inicializar
        %disp('if');
    else
        
        matrizInit={'pH','EC','Tds','Sal','Temperatura','Fecha','Hora'};%se inicializa el archivo con nombres en la fila 1
        sheet = 'Hoja1';
        xlRange = 'B1:H1';
        xlswrite(filename,matrizInit,sheet,xlRange)
        %----------------------------------
        %contador=0
        contador = 2;
        sheet = 'Hoja1';
        xlRange = 'A1';
        xlswrite(filename,contador,sheet,xlRange)% se ecribe contador = 2, para �iar desde ah� a escribir
        %----------------------------------
        %disp('else')
    end
    %disp(columnB);
    %disp('fer');
    %    cad='B'%cad es una variable auxiliar        
    %    cad1= int2str(contador)%se convierte el valor de "contador", que es int a string
    %    cad2=strcat(cad,cad1)%se concatena 'B' con el valor de contador, para seleccionar la fila donde se va a escribir

