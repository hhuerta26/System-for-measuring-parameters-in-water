%disp()para mostrar
function varargout = Monitoreo_CuValles(varargin)
% MONITOREO_CUVALLES MATLAB code for Monitoreo_CuValles.fig
%      MONITOREO_CUVALLES, by itself, creates a new MONITOREO_CUVALLES or raises the existing
%      singleton*.
%
%      H = MONITOREO_CUVALLES returns the handle to a new MONITOREO_CUVALLES or the handle to
%      the existing singleton*.
%
%      MONITOREO_CUVALLES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MONITOREO_CUVALLES.M with the given input arguments.
%
%      MONITOREO_CUVALLES('Property','Value',...) creates a new MONITOREO_CUVALLES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Monitoreo_CuValles_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Monitoreo_CuValles_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Monitoreo_CuValles

% Last Modified by GUIDE v2.5 21-Feb-2019 09:40:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Monitoreo_CuValles_OpeningFcn, ...
                   'gui_OutputFcn',  @Monitoreo_CuValles_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Monitoreo_CuValles is made visible.
function Monitoreo_CuValles_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Monitoreo_CuValles (see VARARGIN)

% Choose default command line output for Monitoreo_CuValles
global Error%variable global para almacenar errores
handles.output = hObject;
inicializar_archivo();%se inicializa o se crea el archivo
set(handles.pH,'String','0');%se inicializan los textos donde se mostraran los datos sensados
set(handles.Ec,'String','0');
set(handles.Sst,'String','0');
set(handles.Sal,'String','0');
set(handles.Temperatura,'String','0');
set(handles.Fecha,'String','0');
set(handles.Hora,'String','0');
set(handles.T_muestreoTxt,'String','');
set(handles.ConfigHoraTxt,'String','');
set(handles.TxtError_T,'String','');
Error=1;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Monitoreo_CuValles wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Monitoreo_CuValles_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
get(hObject,'Value')

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

contents = cellstr(get(hObject,'String'))
%contents{get(hObject,'Value')}
% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
contents = cellstr(get(hObject,'String'))

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
global com
global x
Puerto_Serial = cellstr(get(hObject,'String'));%se le el puerto COM, s� el usuario eligio uno
com=Puerto_Serial{get(hObject,'Value')}%%se lee el puerto com seleccionado
%contents = cellstr(get(hObject,'String'))
%com=contents{get(hObject,'Value')}
%S=serial(com,'BaudRate',9600);


%switch(com)
 %   case 1
 %       try
  
  %S=serial('COM2','BaudRate',9600);
%            fopen(S);
%           fprintf(s,'%s','tam');
%            fclose(S);
%       catch
%            fclose(S);
%        end
%    case 2
%        try
%        S=serial('COM2','BaudRate',9600);
%            fopen(S);
%            fprintf(s,'%s','tam');
%            fclose(S);
%        catch
%            fclose(S);
%        end
%end
        
% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)%desconectar
global x
x=2;
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)%conectar
global x %variable global para saber cuando se preciono el boton de desconectar com
global com %variable global para almacenar el puerto com seleccionado por el usuario
global pH_global%variables globales para almacenar los datos recibidos
global EC_global
global Tds_global
global Sal_global
global Temperatura_global
global fecha_global
global fecha_Com_global
global Error
global S %variable global para almacenar el puerto com que se abrio
x=0;


try
    S=serial(com,'BaudRate',9600,'Terminator','CR');%se abre el puerto COM con los siguientes parametros 9600baudios, fin de cadena el retorno de carro
    fopen(S);% se abre el puerto COM
    set(handles.ErrorDatos,'String', '');%Texto para mostrar si hubo error l abrir el puerto COM
    set(handles.text2,'String','Conexion correcta');%Se muestra que la conexi�n fue correcta
    Error=0;%no hubo error
    set(handles.TxtError_T,'String','');
    while(x==0)%mientras x==0 es porque no sea precionado el boton de dsconectar
       
        fprintf(S,'%s','1');%se pide el pH al micro (con el comando 1)
        pause(.2)%pause
        pH_global=fscanf(S,'%s');%Se lee el pH por puerto com
        %disp(pH_global);
        %disp(length(pH_global))
        if(length(pH_global)<1)%s� cadena pH<1 es porque no hay datos, el micro aun no recibe ningun SMS (no hay datos que mostrar porque el micro estaba ocupado)
         %   disp('continue')
            pause(1)%espera 1s
            continue%continua para volver a preguntar si ya hay datos (vuelve a preguntar por pH)
        end
        if(pH_global=='a')%no ha datos que mostrar
          % disp('continue')
            pause(.8)
            fprintf(S,'%s','7');%se pide s� hay alguna confirmaci�n de configuraci�n
            pause(.2)
            dato=fscanf(S,'%s');%Se lee el dato de configuraci�n
            if(length(dato)>1)% si cadena dato>1 es porque tiene informaci�n por lo tanto se mostrara la confirmaci�n recibia

                set(handles.ConfirmacionConfig,'String',sprintf('Confirmaci�n de configuraci�n, dato = %s',dato));%se muestra la confirmaci�n recibida
            end     
            continue
        end
        fprintf(S,'%s','2');%se pide conductividad
        pause(.2)
        EC_global=fscanf(S,'%s');%se lee conductivida
        %disp(EC_global)
        if(EC_global=='a')%S� Ec_global==1 es porque no hay datos que mostrar
            %disp('continue')
            pause(1)
            continue
        end
        if(length(EC_global)<1)% el micro estaba ocupado o se perd�o informacion
         %   disp('continue')
            pause(1)
            continue
        end
        fprintf(S,'%s','3');%se pide Tds
        pause(.2)
        Tds_global=fscanf(S,'%s');%se lee Tds
        %disp(Tds_global)
        fprintf(S,'%s','4');%Se pide Sl
        pause(.2)
        Sal_global=fscanf(S,'%s');%Se lee sal
        if(Tds_global=='a')
            %disp('continue')
            pause(1)
            continue
        end
        if(length(Tds_global)<1)
         %   disp('continue')
            pause(1)
            continue
        end
        
        %disp(Sal_global)
        fprintf(S,'%s','5');%se pide temperatura
        pause(.2)
        if(Sal_global=='a')
            %disp('continue')
            pause(1)
            continue
        end
        if(length(Sal_global)<1)
         %   disp('continue')
            pause(1)
            continue
        end
        Temperatura_global=fscanf(S,'%s');%se lee temperatura
        %disp(Temperatura_global)
        fprintf(S,'%s','6');
        pause(.2)
        fecha_Com_global=fscanf(S,'%s');%se lee fecha
        %disp(fecha_Com_global)
        Escribir_archivo();% se escriban los datos en el archivo de excel
        
    end
    fclose(S);
    delete(S);
    
    
    set(handles.text2,'String','');
catch
fclose(S);
delete(S);
set(handles.text2,'String','Error al conectar puerto COM elija otro COM');
set(handles.ErrorDatos,'String', 'Error los datos no se pueden alamacenar');
Error=1;
 pause(10)
end
set(handles.text2,'String','');

%disp(x)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
global x
x=2
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function text2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pH_Callback(hObject, eventdata, handles)
% hObject    handle to pH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pH as text
%        str2double(get(hObject,'String')) returns contents of pH as a double


% --- Executes during object creation, after setting all properties.
function pH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ec_Callback(hObject, eventdata, handles)
% hObject    handle to Ec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ec as text
%        str2double(get(hObject,'String')) returns contents of Ec as a double


% --- Executes during object creation, after setting all properties.
function Ec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Sal_Callback(hObject, eventdata, handles)
% hObject    handle to Sal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sal as text
%        str2double(get(hObject,'String')) returns contents of Sal as a double


% --- Executes during object creation, after setting all properties.
function Sal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Temp_Callback(hObject, eventdata, handles)
% hObject    handle to Temp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Temp as text
%        str2double(get(hObject,'String')) returns contents of Temp as a double


% --- Executes during object creation, after setting all properties.
function Temp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Temp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Sst_Callback(hObject, eventdata, handles)
% hObject    handle to Sst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sst as text
%        str2double(get(hObject,'String')) returns contents of Sst as a double


% --- Executes during object creation, after setting all properties.
function Sst_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Fecha_Callback(hObject, eventdata, handles)
% hObject    handle to Fecha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fecha as text
%        str2double(get(hObject,'String')) returns contents of Fecha as a double


% --- Executes during object creation, after setting all properties.
function Fecha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fecha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Hora_Callback(hObject, eventdata, handles)
% hObject    handle to Hora (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Hora as text
%        str2double(get(hObject,'String')) returns contents of Hora as a double


% --- Executes during object creation, after setting all properties.
function Hora_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Hora (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function T_muestreoTxt_Callback(hObject, eventdata, handles)
% hObject    handle to T_muestreoTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of T_muestreoTxt as text
%        str2double(get(hObject,'String')) returns contents of T_muestreoTxt as a double


% --- Executes during object creation, after setting all properties.
function T_muestreoTxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to T_muestreoTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ConfigHoraTxt_Callback(hObject, eventdata, handles)
% hObject    handle to ConfigHoraTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ConfigHoraTxt as text
%        str2double(get(hObject,'String')) returns contents of ConfigHoraTxt as a double


% --- Executes during object creation, after setting all properties.
function ConfigHoraTxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ConfigHoraTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Fecha_HoraBut.
function Fecha_HoraBut_Callback(hObject, eventdata, handles)
% hObject    handle to Fecha_HoraBut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
%funci�n para manejar el boton de fecha
global Error
global S
CadFecha_Hora=get(handles.ConfigHoraTxt,'String');
if(Error==1)%si hubo un error, es porque no se ha conectado a un puerto COM, se muestra el siguiente mensaje
       set(handles.TxtError_T,'String','Primero conetarse a un puerto COM');
else%s� esta conectado a un puerto COM, se introduce un dato y se preciona el boton
    if(length(CadFecha_Hora)==20)%s� el dato escrito tiene un largo de 20
        if((CadFecha_Hora(1)>='0' && CadFecha_Hora(1)<='9') && (CadFecha_Hora(2)>='0' && CadFecha_Hora(2)<='9')&& (CadFecha_Hora(3)=='/') && (CadFecha_Hora(4)>='0' && CadFecha_Hora(4)<='9') && (CadFecha_Hora(5)>='0' && CadFecha_Hora(5)<='9') && CadFecha_Hora(6)=='/' && (CadFecha_Hora(7)>='0' && CadFecha_Hora(7)<='9') && (CadFecha_Hora(8)>='0' && CadFecha_Hora(8)<='9') && CadFecha_Hora(9)==',' && (CadFecha_Hora(10)>='0' && CadFecha_Hora(10)<='9') && (CadFecha_Hora(11)>='0' && CadFecha_Hora(11)<='9') && CadFecha_Hora(12)==':' && (CadFecha_Hora(13)>='0' && CadFecha_Hora(13)<='9')&& (CadFecha_Hora(14)>='0' && CadFecha_Hora(14)<='9') && CadFecha_Hora(15)==':' && (CadFecha_Hora(16)>='0' && CadFecha_Hora(16)<='9') && (CadFecha_Hora(17)>='0' && CadFecha_Hora(17)<='9') && (CadFecha_Hora(18)=='+' || CadFecha_Hora(18)=='-') && (CadFecha_Hora(19)>='0' && CadFecha_Hora(19)<='9') && (CadFecha_Hora(20)>='0' && CadFecha_Hora(20)<='9'))
            %Ejemplo de fecha: 19/04/29,08:05:05+00, s� la cadena es
            %correcta para configurar una hora se env�a por puerto COM
            set(handles.TxtError_T,'String','');
            buffer=sprintf('%s%s%s','#"',CadFecha_Hora,'"#')
            fprintf(S,'%s',buffer);
         %   disp('sii')
        else%s� la fecha y hora no es valida
          %  disp('else')
            set(handles.ConfigHoraTxt,'String','Error, introduzca la fecha correcta AA\MM\DD,HH:MM:SS+ZH');
        end

    else%s� la fecha se introdujo mal
        %disp('else')
        set(handles.TxtError_T,'String','Error, introduzca la fecha correcta AA/MM/DD,HH:MM:SS+ZH');
    end
end

set(handles.ConfigHoraTxt,'String','');
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pushbutton1.
function pushbutton1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over T_muestreoTxt.
function T_muestreoTxt_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to T_muestreoTxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in T_MuestreoBut.
function T_MuestreoBut_Callback(hObject, eventdata, handles)
% hObject    handle to T_MuestreoBut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Error
global S
%disp('Press')
%funcion para boton de configuraci�n de tiempo de muetreo
CadT_Muestreo=get(handles.T_muestreoTxt,'String')
%disp(Error)
set(handles.ConfirmacionConfig,'String','')
if(Error==1)%s� hay error es porque no se ha conectado a un puerto COM
    set(handles.TxtError_T,'String','Primero conetarse a un puerto COM');
else%S� no hay error
   if(length(CadT_Muestreo)==3)%s� cadena tiene un largo de 3, se verifica s� el comando es correcto
        if((CadT_Muestreo(1)>='0' && CadT_Muestreo(1)<='9') && (CadT_Muestreo(2)>='0' && CadT_Muestreo(2)<='9')&& (CadT_Muestreo(3)>='0' && CadT_Muestreo(3)<='9'))
            set(handles.TxtError_T,'String','');%s� el comando es correcto, se env�a el tiempo de muestreo por COM para que el micro env�e el SMS de configuraci�n
            buffer=sprintf('%s%s%s','#"',CadT_Muestreo,'"#')
            fprintf(S,'%s',buffer);
            pause(.1)
        else%s� el comando tiene 3 de largo pero esta incorrecot se muestra el siguiente mensaje en pantalla
 %           disp('else')
            set(handles.TxtError_T,'String','Error, introdusca 3 Numeros');
        end

   else%si el comando tiene un largo mayor a 3 se muestra el siguiente mensaje
      %  disp('else')
        set(handles.TxtError_T,'String','Error, introdusca 3 Numeros');
    end
    set(handles.T_muestreoTxt,'String',''); 
end





% --- Executes on key press with focus on Fecha_HoraBut and none of its controls.
function Fecha_HoraBut_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to Fecha_HoraBut (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on button press in PeticionBut.
function PeticionBut_Callback(hObject, eventdata, handles)
% hObject    handle to PeticionBut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global S
global Error
if(Error==1)
    set(handles.TxtError_T,'String','Primero conetarse a un puerto COM');
else
    fprintf(S,'%s','#Dato#');
end


% --- Executes during object creation, after setting all properties.
function axes4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
a=imread('UdG.jpg');
image(a)
axis off
% Hint: place code in OpeningFcn to populate axes4


% --- Executes during object creation, after setting all properties.
function axes5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
a=imread('UdG.jpg');
image(a)
axis off
% Hint: place code in OpeningFcn to populate axes5
